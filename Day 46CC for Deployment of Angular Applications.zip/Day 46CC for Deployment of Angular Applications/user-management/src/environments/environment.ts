export const environment = {
  production: false,
  apiUrl: 'https://jsonplaceholder.typicode.com'
};