export const environment = {
  production: true,
  apiUrl: 'https://jsonplaceholder.typicode.com'
};