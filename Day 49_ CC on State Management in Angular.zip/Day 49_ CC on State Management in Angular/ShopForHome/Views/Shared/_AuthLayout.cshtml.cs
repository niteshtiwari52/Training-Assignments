using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ShopForHome.Views.Shared
{
    public class _AuthLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
