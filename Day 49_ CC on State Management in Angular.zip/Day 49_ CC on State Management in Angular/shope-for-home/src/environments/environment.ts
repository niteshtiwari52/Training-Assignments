export const environment = {
  production: true,
  apiUrl: 'https://localhost:7086/api',
  imageBaseURL: 'https://localhost:7086'
};