import { TaskState } from './task.model';

export interface AppState {
  tasks: TaskState;
}